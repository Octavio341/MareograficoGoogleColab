# script_secundario.py
print("✅ ¡El script secundario se ejecutó correctamente!")
